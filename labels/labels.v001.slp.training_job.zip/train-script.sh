#!/bin/bash
sleap-train single_instance.json labels.v001.pkg.slp
